package compiler.interpret;
import compiler.node.*;
import compiler.analysis.*;

import java.util.*;

public class SymbolTable extends DepthFirstAdapter {
/*
	Hashtable symbol_table = new Hashtable();
	
	//Override metod from DepthFirstAdapter
	public void outAIdentifierValue(AIdentifierValue node){
		// Gets the identifier tokens value (name of the identifier)
		TIdentifier ident = node.getIdentifier();
		
		// Convert ident to uppercase text and stores it in String key
		String key = ident.getText().toUpperCase();		
		if (!symbol_table.containsKey(key))
		{
			System.out.println("Variable --> " + ident.getText() + " <-- isn't declared before use");
			//System.exit(0);
		}
	}
	
	public void outAVariableDeclarationDecl(ASingleVar node){
		// Gets the identifier tokens value (name of the identifier)
		TIdentifier ident = node.getIdentifier();
		
		// 
		String key = ident.getText().toUpperCase();
		
		if (symbol_table.containsKey(key)){
			System.out.println("Variable --> " + ident.getText() + " <-- is already declared");
			//System.exit(0);
		}
		else{
			symbol_table.put(key, key);
		}
	}
	*/
}
